# Instalar perfil GitHub de FabioHorna

1. Crea en https://github.com/new un repositorio **público** llamado `FabioHorna`, bajo la cuenta `FabioHorna`.
2. Puedes marcar "Add a README file". Después, en esta conversación, pide publicar el perfil: la conexión GitHub podrá crear o actualizar archivos de texto en el repositorio.
3. El README y los archivos SVG de `assets/`, además de `.github/workflows/metrics.yml`, son los archivos que hay que publicar.
4. Para generar métricas reales, agrega un secreto GitHub Actions `METRICS_TOKEN` con permisos mínimos de lectura apropiados, revisa el workflow y ejecútalo manualmente.

No se han incluido números de actividad ficticios ni un distintivo de Anthropic Partner no verificado. No publiques tokens o contraseñas en el repositorio.
